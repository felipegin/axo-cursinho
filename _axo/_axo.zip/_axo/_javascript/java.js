		function ligaseta()
		{
			document.getElementById("seta").src = "_imagens/axosite4.png";
		}
		function desligaseta()
		{
			document.getElementById("seta").src ="_imagens/axosite5.png";
		}